package bg.tu.varna.pictureurlintoimageview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button buton4e;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        buton4e = (Button) findViewById(R.id.buton4e);
        buton4e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityWithImage();
            }
        });
    }

    public void openActivityWithImage()
        {
            Intent toOpenActivityWithImage = new Intent(this, ActivityWithImage.class);
            startActivity(toOpenActivityWithImage);
        }

}